package com.sharing.bookauto.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.sharing.bookauto.Model.DriverModel;
import com.sharing.bookauto.Model.TripModel;
import com.sharing.bookauto.databinding.ItemTripBinding;
import com.sharing.bookauto.databinding.OtpLayoutBinding;

import java.util.ArrayList;
import java.util.HashMap;

public class TripsAdapter extends RecyclerView.Adapter<TripsAdapter.ViewHolder> {

    private Context context;
    private ArrayList<TripModel> list;
    String from;

    public TripsAdapter(Context context, ArrayList<TripModel> list,String from) {
        this.context = context;
        this.list = list;
        this.from = from;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemTripBinding binding = ItemTripBinding.inflate(LayoutInflater.from(context),parent,false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        holder.bind(list.get(position),context,from);

        holder.binding.tripCount.setText("Trip#"+position);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ItemTripBinding binding;
        public ViewHolder(@NonNull ItemTripBinding itemView) {
            super(itemView.getRoot());
            binding = itemView;
        }

        void bind(TripModel model, Context context, String from){
            binding.username.setText(model.getUsername());
            binding.phone.setText(model.getUser_phone());
            binding.tripId.setText(model.getTrip_id());
            binding.pickup.setText(model.getPickup());
            binding.drop.setText(model.getDrop());
            binding.amount.setText("₹"+model.getCost());

            binding.status.setText(model.getStatus());

            if (from.equalsIgnoreCase("user")){
                binding.btnACcept.setVisibility(View.GONE);
            }else {
                if (model.getStatus().equalsIgnoreCase("Confirmed")){
                    binding.btnACcept.setText("Dropped");

                    binding.btnACcept.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            //droped
                            dropped(model);
                        }
                    });

                }else if (model.getStatus().equalsIgnoreCase("Pending")){
                    binding.btnACcept.setText("Accept");

                    binding.btnACcept.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            BottomSheetDialog dialog = new BottomSheetDialog(context);
                            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                            dialog.setCancelable(true);
                            OtpLayoutBinding otpLayoutBinding = OtpLayoutBinding.inflate(LayoutInflater.from(context));
                            dialog.setContentView(otpLayoutBinding.getRoot());

                            otpLayoutBinding.btnConfirm.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    String otp = otpLayoutBinding.inputOtp.getText().toString();
                                    if (otp.isEmpty()){
                                        Toast.makeText(context, "Enter otp", Toast.LENGTH_SHORT).show();
                                    }else {
                                        validateOTP(otp,model,dialog);
                                    }
                                }
                            });

                            dialog.show();

                        }
                    });

                }else {
                    binding.btnACcept.setVisibility(View.GONE);
                }
            }

        }

        private void dropped(TripModel model) {
            DatabaseReference reference = FirebaseDatabase.getInstance().getReference();


            HashMap<String,Object> map = new HashMap<>();
            map.put("status","Dropped");

            reference.child("Trips").child(model.getTrip_id()).updateChildren(map).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void unused) {
                    reference.child("Drivers").child(model.getDriver_id()).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            DriverModel driverModel = snapshot.getValue(DriverModel.class);

                            HashMap<String,Object> map = new HashMap<>();
                            map.put("seats",driverModel.getSeats() + model.getPersons());

                            reference.child("Drivers").child(model.getDriver_id()).updateChildren(map);

                            Toast.makeText(context, "Dropped", Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });

                }
            });
        }

        private void validateOTP(String otp, TripModel model, BottomSheetDialog dialog) {
            if (otp.equalsIgnoreCase(model.getOtp())){



                DatabaseReference reference = FirebaseDatabase.getInstance().getReference();


                HashMap<String,Object> map = new HashMap<>();
                map.put("status","Confirmed");

                reference.child("Trips").child(model.getTrip_id()).updateChildren(map).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        reference.child("Drivers").child(model.getDriver_id()).addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if (snapshot.exists()){
                                    DriverModel driverModel = snapshot.getValue(DriverModel.class);

                                    HashMap<String,Object> map = new HashMap<>();
                                    map.put("seats",driverModel.getSeats() - model.getPersons());

                                    reference.child("Drivers").child(model.getDriver_id()).updateChildren(map);

                                    Toast.makeText(context, "Booking confirmed", Toast.LENGTH_SHORT).show();
                                    binding.btnACcept.setText("Dropped");
                                    dialog.dismiss();
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });

                    }
                });





            }else {
                Toast.makeText(context, "Invalid OTP", Toast.LENGTH_SHORT).show();
            }

        }
    }


}
