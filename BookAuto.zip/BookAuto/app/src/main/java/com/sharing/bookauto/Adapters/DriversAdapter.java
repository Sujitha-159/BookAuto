package com.sharing.bookauto.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.sharing.bookauto.Activities.MapsActivity;
import com.sharing.bookauto.ConfirmationActivity;
import com.sharing.bookauto.Model.DriverModel;
import com.sharing.bookauto.Model.TripModel;
import com.sharing.bookauto.R;
import com.sharing.bookauto.Utils.CustPrograssbar;
import com.sharing.bookauto.Utils.PreferenceManager;
import com.sharing.bookauto.databinding.BottomTripSelectBinding;
import com.sharing.bookauto.databinding.ItemDriverBinding;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Random;

public class DriversAdapter extends RecyclerView.Adapter<DriversAdapter.ViewHolder> {

    private Context context;
    private ArrayList<DriverModel> list;

    public DriversAdapter(Context context, ArrayList<DriverModel> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemDriverBinding binding = ItemDriverBinding.inflate(LayoutInflater.from(context),parent,false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        DriverModel model = list.get(position);
        if (model !=null){
            holder.setData(model,context);
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ItemDriverBinding binding;
        CustPrograssbar custPrograssbar;
        PreferenceManager preferenceManager;
        public ViewHolder(@NonNull ItemDriverBinding itemView) {
            super(itemView.getRoot());
            binding = itemView;
        }

        void setData(DriverModel model, Context context){
            preferenceManager= new PreferenceManager(context);
            custPrograssbar = new CustPrograssbar();
            try {
                Picasso.get().load(model.getProfile()).placeholder(R.drawable.placeholder)
                        .into(binding.driverImage);
            }catch (Exception e){
                e.printStackTrace();
            }
            binding.driverName.setText(model.getDriver_name());
            binding.seats.setText(model.getSeats()+" seats avail");
            binding.cost.setText("₹"+model.getCost()+"/km");

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    BottomSheetDialog dialog = new BottomSheetDialog(context);
                    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    dialog.setCancelable(true);
                    BottomTripSelectBinding selectBinding = BottomTripSelectBinding.inflate(LayoutInflater.from(context));
                    dialog.setContentView(selectBinding.getRoot());

                    int seats = model.getSeats();

                    selectBinding.name.setText(model.getDriver_name());

                    try {
                        Picasso.get().load(model.getProfile()).placeholder(R.drawable.placeholder)
                                .into(selectBinding.driverImage);
                    }catch (Exception e){
                        e.printStackTrace();
                    }

                    selectBinding.seatsCount.setText(String.valueOf(seats));

                    selectBinding.btnBook.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            String pickup = selectBinding.inputPickup.getText().toString();
                            String drop = selectBinding.inputDrop.getText().toString();
                            String persons = selectBinding.inputPersons.getText().toString();
                            if (pickup.isEmpty() || drop.isEmpty() || persons.isEmpty()){
                                Toast.makeText(context, "Enter picup location and drop location", Toast.LENGTH_SHORT).show();
                            }else if (Integer.parseInt(persons) > seats){
                                Toast.makeText(context, "This vehicle doesn't have enough seats for you!", Toast.LENGTH_SHORT).show();
                            }

                            else {
                                bookTrip(pickup,drop,persons,model,dialog);
                            }
                        }
                    });


                    dialog.show();



                }
            });

            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    Intent intent = new Intent(context, MapsActivity.class);
                    intent.putExtra("driverId",model.getUid());
                    context.startActivity(intent);
                    return false;
                }
            });

        }

        private void bookTrip(String pickup, String drop, String persons, DriverModel driverModel, BottomSheetDialog dialog) {
            custPrograssbar.prograssCreate(context,"Booking...");

            Random random = new Random();
            int randomNumber = random.nextInt(6) + 10;

            int cost = randomNumber * driverModel.getCost();

            DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Trips");
            //userdata
            String username = preferenceManager.getString("name");
            String email = preferenceManager.getString("email");
            String phone = preferenceManager.getString("phone");
            String otp = preferenceManager.getString("otp");

            String trip_id = reference.push().getKey();

            TripModel model = new TripModel();

            model.setTrip_id(trip_id);
            model.setDriver_id(driverModel.getUid());
            model.setUserid(FirebaseAuth.getInstance().getCurrentUser().getUid());
            model.setDistance(randomNumber);
            model.setCost(cost);
            model.setUsername(username);
            model.setUser_phone(phone);
            model.setDriver_phone(driverModel.getDriver_phone());
            model.setDriver_profile(model.getDriver_profile());
            model.setDriver_name(driverModel.getDriver_name());
            model.setTimestamp(System.currentTimeMillis());
            model.setOtp(otp);
            model.setPickup(pickup);
            model.setDrop(drop);
            model.setPersons(Integer.parseInt(persons));
            model.setStatus("Pending");

            assert trip_id != null;
            reference.child(trip_id).setValue(model).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void unused) {
                    Intent intent = new Intent(context, ConfirmationActivity.class);
                    intent.putExtra("driver_id",driverModel.getUid());
                    intent.putExtra("amount",cost);
                    intent.putExtra("persons",persons);
                    intent.putExtra("distance",randomNumber);
                    intent.putExtra("trip_id",trip_id);

                    context.startActivity(intent);
                    dialog.dismiss();

                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    custPrograssbar.closePrograssBar();
                    Toast.makeText(context, "Error: "+e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });


        }
    }


}
