package com.sharing.bookauto.Authentication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.sharing.bookauto.Model.DriverModel;
import com.sharing.bookauto.Model.UserModel;
import com.sharing.bookauto.R;
import com.sharing.bookauto.Utils.CustPrograssbar;
import com.sharing.bookauto.Utils.PreferenceManager;
import com.sharing.bookauto.databinding.ActivityUserCreateBinding;

import java.util.Random;

public class UserCreateActivity extends AppCompatActivity {

    ActivityUserCreateBinding binding;

    private PreferenceManager preferenceManager;
    DatabaseReference reference;
    FirebaseAuth auth;

    private CustPrograssbar custPrograssbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUserCreateBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        auth = FirebaseAuth.getInstance();
        reference = FirebaseDatabase.getInstance().getReference().child("Users");
        custPrograssbar = new CustPrograssbar();

        binding.inputLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showCities();
            }
        });


        binding.btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = binding.inputUsername.getText().toString();
                String email = binding.inputEmail.getText().toString();
                String phone = binding.inputPhone.getText().toString();
                String location = binding.inputLocation.getText().toString();
                String password = binding.inputPassword.getText().toString();

                if (name.isEmpty() || email.isEmpty() || phone.isEmpty() || location.isEmpty()){
                    Toast.makeText(UserCreateActivity.this, "Enter valid data", Toast.LENGTH_SHORT).show();
                }else {
                    signup(name,email,phone,location,password);
                }
            }
        });

    }

    private void signup(String name, String email, String phone, String location, String password) {

        custPrograssbar.prograssCreate(UserCreateActivity.this,"Creating account...");


        auth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){

                    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

                    UserModel model = new UserModel();
                    model.setUsername(name);
                    model.setEmail(email);
                    model.setPhone(phone);
                    model.setTimestamp(System.currentTimeMillis());
                    model.setLocation(location);
                    model.setUid(user.getUid());
                    model.setProfile("");
                    model.setOtp(String.valueOf(new Random().nextInt(100000)));
                    reference.child(user.getUid()).setValue(model).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            Intent intent = new Intent(UserCreateActivity.this,UserLoginActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                            preferenceManager.putBoolean("login",false);
                            finish();
                            custPrograssbar.closePrograssBar();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            custPrograssbar.closePrograssBar();
                            Toast.makeText(UserCreateActivity.this, "Error: "+e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });


                }else {
                    custPrograssbar.closePrograssBar();
                    Toast.makeText(UserCreateActivity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });












    }


    private void showCities(){
        AlertDialog.Builder builder = new AlertDialog.Builder(UserCreateActivity.this);
        builder.setTitle("Select location");
        builder.setCancelable(false);
        String[] items = {"Kanuru","Patamata","Benz Circle","One town","Sing Nagar"};
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                ListView listView = ((AlertDialog)dialogInterface).getListView();
                Object object = listView.getItemAtPosition(i);
                binding.inputLocation.setText(object.toString());
                dialogInterface.dismiss();
            }
        });

        builder.setPositiveButton("Close",null);
        builder.create().show();
    }
}