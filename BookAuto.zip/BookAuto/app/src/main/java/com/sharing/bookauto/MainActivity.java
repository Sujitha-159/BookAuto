package com.sharing.bookauto;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.sharing.bookauto.Adapters.DriversAdapter;
import com.sharing.bookauto.Authentication.UserLoginActivity;
import com.sharing.bookauto.Model.DriverModel;
import com.sharing.bookauto.Utils.PreferenceManager;
import com.sharing.bookauto.databinding.ActivityMainBinding;
import com.sharing.bookauto.databinding.BottomListBinding;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    ActivityMainBinding binding;

    private PreferenceManager preferenceManager;
    String location;

    DatabaseReference reference;

    private ArrayList<DriverModel> list = new ArrayList<>();
    private DriversAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        preferenceManager = new PreferenceManager(this);
        location = preferenceManager.getString("location");
        reference = FirebaseDatabase.getInstance().getReference().child("Drivers");

        if (location !=null){
            binding.location.setText(location);

        }else {
            binding.location.setText("Select location");
        }

        binding.recyclerView.setHasFixedSize(true);
        binding.recyclerView.setLayoutManager(new GridLayoutManager(MainActivity.this,3));
        binding.recyclerView.setItemAnimator(new DefaultItemAnimator());


        getDriversData(location);



        binding.btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                preferenceManager.clear();
                Intent intent = new Intent(MainActivity.this, UserLoginActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            }
        });

        binding.location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changeLocation();
            }
        });

        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,DataActivity.class)
                        .putExtra("from","user"));
            }
        });
    }

    private void changeLocation(){
        BottomSheetDialog dialog = new BottomSheetDialog(MainActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        BottomListBinding bottomListBinding = BottomListBinding.inflate(getLayoutInflater());
        dialog.setContentView(bottomListBinding.getRoot());

        ListView listView = bottomListBinding.listView;
        List<String> itemList = Arrays.asList("Kanuru","Patamata","Benz Circle","One town","Sing Nagar");
//        String[] items = {"Kanuru","Patamata","Benz Circle","One town","Sing Nagar"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, itemList);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                location = listView.getItemAtPosition(i).toString();
                binding.location.setText(location);
                getDriversData(location);
                dialog.dismiss();
            }
        });


        dialog.show();


    }

    private void getDriversData(String loc) {
        binding.progressBar.setVisibility(View.VISIBLE);
        binding.layout.getRoot().setVisibility(View.GONE);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    list.clear();
                    binding.progressBar.setVisibility(View.GONE);
                    binding.layout.getRoot().setVisibility(View.GONE);
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                        DriverModel model = dataSnapshot.getValue(DriverModel.class);
                        if (model.getLocation().equalsIgnoreCase(loc)){
                            list.add(model);
                        }
                    }

//                    Toast.makeText(MainActivity.this, "Size: "+list.size(), Toast.LENGTH_SHORT).show();
                    adapter = new DriversAdapter(MainActivity.this,list);
                    binding.recyclerView.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                }else {
                    binding.progressBar.setVisibility(View.GONE);
                    binding.layout.getRoot().setVisibility(View.VISIBLE);
                    binding

                            .layout.text.setText("No drivers found!");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                binding.progressBar.setVisibility(View.GONE);
                binding.layout.getRoot().setVisibility(View.VISIBLE);
                binding.layout.text.setText("No drivers found!\nError: "+ error.getMessage());

            }
        });
    }
}