package com.sharing.bookauto.Authentication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.sharing.bookauto.Activities.DriverMainActivity;
import com.sharing.bookauto.Model.DriverModel;
import com.sharing.bookauto.Model.UserModel;
import com.sharing.bookauto.R;
import com.sharing.bookauto.Utils.CustPrograssbar;
import com.sharing.bookauto.Utils.PreferenceManager;
import com.sharing.bookauto.databinding.ActivityDriverLoginBinding;

public class DriverLoginActivity extends AppCompatActivity {

    
    ActivityDriverLoginBinding binding;
    
    private PreferenceManager preferenceManager;
    DatabaseReference reference;
    FirebaseUser user;
    FirebaseAuth auth;

    private CustPrograssbar custPrograssbar;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDriverLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        
        preferenceManager = new PreferenceManager(this);
        auth = FirebaseAuth.getInstance();
        reference = FirebaseDatabase.getInstance().getReference().child("Drivers");
        custPrograssbar = new CustPrograssbar();
        
        binding.btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = binding.inputDriverEmail.getText().toString();
                String password = binding.inputPassword.getText().toString();
                if (email.isEmpty() || password.isEmpty()){
                    Toast.makeText(DriverLoginActivity.this, "Enter valid details", Toast.LENGTH_SHORT).show();
                }else {
                    login(email,password);
                }
            }
        });
        
        
        

        binding.txtCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DriverLoginActivity.this,DriverCreateActivity.class);
                startActivity(intent);
            }
        });
        
        
        
        
        
        
        
    }

    private void login(String email, String password) {
        custPrograssbar.prograssCreate(DriverLoginActivity.this,"Logging....");

        auth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){
                    user = FirebaseAuth.getInstance().getCurrentUser();

                    reference.child(user.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists()){

                                DriverModel model = snapshot.getValue(DriverModel.class);
                                if (model !=null){
                                    custPrograssbar.closePrograssBar();
                                    Intent intent = new Intent(DriverLoginActivity.this, DriverMainActivity.class);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);

                                    preferenceManager.putBoolean("login",true);
                                    preferenceManager.putString("profile",model.getProfile());
                                    preferenceManager.putString("driver_name",model.getDriver_name());
                                    preferenceManager.putString("location",model.getLocation());
                                    preferenceManager.putString("driver_email",model.getDriver_email());
                                    preferenceManager.putString("driver_phone",model.getDriver_phone());
                                    preferenceManager.putString("type","driver");

                                    startActivity(intent);
                                    finish();

                                }

                            }else {
                                custPrograssbar.closePrograssBar();
                                Toast.makeText(DriverLoginActivity.this, "No driver found with this details", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            custPrograssbar.closePrograssBar();
                            Toast.makeText(DriverLoginActivity.this, "Error: "+error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });








                }else {
                    custPrograssbar.closePrograssBar();
                    Toast.makeText(DriverLoginActivity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}