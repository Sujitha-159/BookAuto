package com.sharing.bookauto.Authentication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.sharing.bookauto.Activities.DriverMainActivity;
import com.sharing.bookauto.MainActivity;
import com.sharing.bookauto.Model.DriverModel;
import com.sharing.bookauto.Model.UserModel;
import com.sharing.bookauto.R;
import com.sharing.bookauto.Utils.CustPrograssbar;
import com.sharing.bookauto.Utils.PreferenceManager;
import com.sharing.bookauto.databinding.ActivityUserLoginBinding;

public class UserLoginActivity extends AppCompatActivity {

    ActivityUserLoginBinding binding;

    private PreferenceManager preferenceManager;
    DatabaseReference reference;
    FirebaseUser user;
    FirebaseAuth auth;

    private CustPrograssbar custPrograssbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUserLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        preferenceManager = new PreferenceManager(this);
        auth = FirebaseAuth.getInstance();
        reference = FirebaseDatabase.getInstance().getReference().child("Users");
        custPrograssbar = new CustPrograssbar();

        binding.btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = binding.inputEmail.getText().toString();
                String password = binding.inputPassword.getText().toString();
                if (email.isEmpty() || password.isEmpty()){
                    Toast.makeText(UserLoginActivity.this, "Enter valid details", Toast.LENGTH_SHORT).show();
                }else {
                    login(email,password);
                }
            }
        });

        binding.txtCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(UserLoginActivity.this,UserCreateActivity.class);
                startActivity(intent);
            }
        });

    }
    private void login(String email, String password) {
        custPrograssbar.prograssCreate(UserLoginActivity.this,"Logging....");

        auth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){
                    user = FirebaseAuth.getInstance().getCurrentUser();
                    custPrograssbar.closePrograssBar();
                    reference.child(user.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists()){
                                custPrograssbar.closePrograssBar();

                                UserModel model = snapshot.getValue(UserModel.class);
                                if (model !=null){

                                    Intent intent = new Intent(UserLoginActivity.this, MainActivity.class);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);

                                    preferenceManager.putBoolean("login",true);
                                    preferenceManager.putString("profile",model.getProfile());
                                    preferenceManager.putString("name",model.getUsername());
                                    preferenceManager.putString("email",model.getEmail());
                                    preferenceManager.putString("phone",model.getPhone());
                                    preferenceManager.putString("location",model.getLocation());
                                    preferenceManager.putString("otp",model.getOtp());
                                    preferenceManager.putString("type","User");

                                    startActivity(intent);
                                    finish();

                                }

                            }else {
                                custPrograssbar.closePrograssBar();

                                Toast.makeText(UserLoginActivity.this, "No driver found with this details", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            custPrograssbar.closePrograssBar();
                            Toast.makeText(UserLoginActivity.this, "Error: "+error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });








                }else {
                    custPrograssbar.closePrograssBar();
                    Toast.makeText(UserLoginActivity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


}