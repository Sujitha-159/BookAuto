package com.sharing.bookauto;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Bundle;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.sharing.bookauto.Activities.DriverMainActivity;
import com.sharing.bookauto.Adapters.TripsAdapter;
import com.sharing.bookauto.Model.TripModel;
import com.sharing.bookauto.databinding.ActivityDataBinding;

import java.util.ArrayList;

public class DataActivity extends AppCompatActivity {

    ActivityDataBinding binding;

    private ArrayList<TripModel> list = new ArrayList<>();
    private TripsAdapter adapter;
    DatabaseReference reference;

    FirebaseUser user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDataBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        reference = FirebaseDatabase.getInstance().getReference().child("Trips");

        binding.recyclerView.setHasFixedSize(true);
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(DataActivity.this));
        binding.recyclerView.setItemAnimator(new DefaultItemAnimator());

        user = FirebaseAuth.getInstance().getCurrentUser();

        getTrips();

        binding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


    }
    private void getTrips() {
        binding.progressBar.setVisibility(View.VISIBLE);
        binding.layout.getRoot().setVisibility(View.GONE);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    list.clear();
                    binding.progressBar.setVisibility(View.GONE);
                    binding.layout.getRoot().setVisibility(View.GONE);
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                        TripModel model = dataSnapshot.getValue(TripModel.class);
                        if (model.getUserid().equalsIgnoreCase(user.getUid())){
                            list.add(model);
                        }

                    }

                    adapter = new TripsAdapter(DataActivity.this,list,"user");
                    binding.recyclerView.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                }else {
                    binding.progressBar.setVisibility(View.GONE);
                    binding.layout.getRoot().setVisibility(View.VISIBLE);
                    binding.layout.text.setText("No trips found!");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                binding.progressBar.setVisibility(View.GONE);
                binding.layout.getRoot().setVisibility(View.VISIBLE);
                binding.layout.text.setText("No trips found!\nError: "+ error.getMessage());

            }
        });
    }

}