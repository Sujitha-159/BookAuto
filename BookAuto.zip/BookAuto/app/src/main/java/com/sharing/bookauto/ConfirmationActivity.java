package com.sharing.bookauto;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.sharing.bookauto.Utils.PreferenceManager;
import com.sharing.bookauto.databinding.ActivityConfirmationBinding;

import java.util.HashMap;

public class ConfirmationActivity extends AppCompatActivity {

    ActivityConfirmationBinding binding;

    private String driverId;
    private int persons,distance,amount;
    private String tripId;

    private PreferenceManager preferenceManager;
    private CountDownTimer countDownTimer;

    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityConfirmationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        reference = FirebaseDatabase.getInstance().getReference();

        preferenceManager = new PreferenceManager(this);
        driverId = getIntent().getStringExtra("driver_id");
        distance = getIntent().getIntExtra("distance",0);
        amount = getIntent().getIntExtra("amount",0);
        persons = getIntent().getIntExtra("persons",0);
        tripId = getIntent().getStringExtra("trip_id");

        String otp = preferenceManager.getString("otp");

        binding.otp.setText(otp);

        binding.personsCount.setText(String.valueOf(persons));
        binding.distance.setText(distance+" KM");
        binding.amount.setText("₹"+amount);


        binding.lottieAnimationView.playAnimation();



        timer();

        binding.btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HashMap<String,Object> map = new HashMap<>();
                map.put("status","Cancelled");

                reference.child("Trips").child(tripId).updateChildren(map)
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()){
                                    finish();
                                    Toast.makeText(ConfirmationActivity.this, "Trip cancelled", Toast.LENGTH_SHORT).show();
                                }else {
                                    Toast.makeText(ConfirmationActivity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });



    }


    private void timer(){
        long durationMillis = 100000;

        // Set the interval for the countdown timer in milliseconds (e.g., 1 second)
        long intervalMillis = 1000;

        countDownTimer = new CountDownTimer(durationMillis, intervalMillis) {
            @Override
            public void onTick(long millisUntilFinished) {
                // Update the TextView with the remaining time
                long secondsRemaining = millisUntilFinished / 1000;
                binding.timer.setText("Time remaining: " + secondsRemaining + " seconds");
            }

            @Override
            public void onFinish() {
                // The timer has finished, you can perform any action here
                binding.timer.setText("Timer finished!");
            }
        };

        // Start the countdown timer
        countDownTimer.start();
    }
    @Override
    protected void onDestroy() {
        // Cancel the countdown timer to prevent memory leaks
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        super.onDestroy();
    }
}