package com.sharing.bookauto.Authentication;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.sharing.bookauto.Model.DriverModel;
import com.sharing.bookauto.Utils.CustPrograssbar;
import com.sharing.bookauto.Utils.PreferenceManager;
import com.sharing.bookauto.databinding.ActivityDriverCreateBinding;

public class DriverCreateActivity extends AppCompatActivity {

    ActivityDriverCreateBinding binding;

    private PreferenceManager preferenceManager;
    DatabaseReference reference;
    FirebaseAuth auth;

    private Uri imageUri;
    private CustPrograssbar custPrograssbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDriverCreateBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        auth = FirebaseAuth.getInstance();
        reference = FirebaseDatabase.getInstance().getReference().child("Drivers");
        custPrograssbar = new CustPrograssbar();


        binding.diverImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                startActivityForResult(intent,100);
            }
        });


        binding.inputLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showCities();
            }
        });

        binding.btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = binding.inputDriverName.getText().toString();
                String email = binding.inputDriverEmail.getText().toString();
                String phone = binding.inputDriverPhone.getText().toString();
                String seats = binding.inputSeats.getText().toString();
                String cost = binding.inputCost.getText().toString();
                String location = binding.inputLocation.getText().toString();
                String password = binding.inputPassword.getText().toString();

                if (name.isEmpty() || email.isEmpty() || phone.isEmpty() || seats.isEmpty() || cost.isEmpty() || location.isEmpty()){
                    Toast.makeText(DriverCreateActivity.this, "Enter valid data", Toast.LENGTH_SHORT).show();
                }else if (imageUri == null){
                    Toast.makeText(DriverCreateActivity.this, "Please upload profile picture", Toast.LENGTH_SHORT).show();
                }else {
                    signup(name,email,phone,seats,cost,location,password);
                }
            }
        });


        checkPermissions();


    }

    private void signup(String name, String email, String phone, String seats, String cost, String location, String password) {
        custPrograssbar.prograssCreate(DriverCreateActivity.this,"Creating account..");
        auth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){



                    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                    final StorageReference storageReference = FirebaseStorage.getInstance().getReference().child("Profiles/")
                            .child(user.getUid()).child("image.jpg");
                    storageReference.putFile(imageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                            storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    String link = uri.toString();


                                    DriverModel model = new DriverModel();
                                    model.setDriver_name(name);
                                    model.setDriver_email(email);
                                    model.setDriver_phone(phone);
                                    model.setCost(Integer.parseInt(cost));
                                    model.setSeats(Integer.parseInt(seats));
                                    model.setTimestamp(System.currentTimeMillis());
                                    model.setLocation(location);
                                    model.setUid(user.getUid());
                                    model.setProfile(link);
                                    model.setLatitude(0.0);
                                    model.setLongitude(0.0);

                                    reference.child(user.getUid()).setValue(model).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()){
                                                Intent intent = new Intent(DriverCreateActivity.this,DriverLoginActivity.class);
                                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                                startActivity(intent);
                                                preferenceManager.putBoolean("login",false);
                                                finish();

                                            }else {
                                                custPrograssbar.closePrograssBar();
                                                Toast.makeText(DriverCreateActivity.this, task.getException()
                                                        .getMessage(), Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    });


                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    custPrograssbar.closePrograssBar();
                                    Toast.makeText(DriverCreateActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    });












                }else {
                    custPrograssbar.closePrograssBar();
                    Toast.makeText(DriverCreateActivity.this, "Error: "+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void showCities(){
        AlertDialog.Builder builder = new AlertDialog.Builder(DriverCreateActivity.this);
        builder.setTitle("Select location");
        builder.setCancelable(false);
        String[] items = {"Kanuru","Patamata","Benz Circle","One town","Sing Nagar"};
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                ListView listView = ((AlertDialog)dialogInterface).getListView();
                Object object = listView.getItemAtPosition(i);
                binding.inputLocation.setText(object.toString());
                dialogInterface.dismiss();
            }
        });

        builder.setPositiveButton("Close",null);
        builder.create().show();
    }

    protected void checkPermissions(){
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.TIRAMISU){
            if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_MEDIA_IMAGES)
             != PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(DriverCreateActivity.this,new String[]{Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.ACCESS_FINE_LOCATION},99);
            }
        }else {
            if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(DriverCreateActivity.this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.ACCESS_FINE_LOCATION},99);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100){
            if (resultCode == RESULT_OK && data !=null){
                imageUri = data.getData();
                binding.diverImage.setImageURI(imageUri);
            }
        }else {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }
    }
}